package net.shangtech.security.dao;


import net.shangtech.framework.dao.IBaseDao;
import net.shangtech.security.entity.Role;

public interface IRoleDao extends IBaseDao<Role> {

}
